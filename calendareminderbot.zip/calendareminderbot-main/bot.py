# telegram bot
import logging

from telegram.ext import (CallbackQueryHandler, CommandHandler,
                          ConversationHandler, Filters, InlineQueryHandler,
                          MessageHandler)

from functions.admin_publish import admin_publish, publish_text, send_publish_text
from functions.all_group_events import show_events
# custom functions
from functions.calendar import cal, change_date
from functions.cancel import cancel
from functions.change_date_event import change_event_date, redate_event
from functions.change_notification_event import change_notification_event, renotify, disable_change_notification_time
from functions.change_privacy import change_privacy
from functions.change_time_event import change_event_time, retime_event
from functions.check_hour import check_hour, schedule_timer
from functions.date_events import events, event_cal
from functions.delete_event import delete_event
from functions.delete_group import delete_group
from functions.event import event_init, change_event
from functions.get_group_id import get_group_id
from functions.get_groups import mygroups
from functions.group_create import add_group
from functions.group_event import plan_group_event, privacy_change_confirmation
from functions.group_join import join_group
from functions.group_list_view import group_list_view
from functions.group_manage import manage_group
from functions.group_manage_view import group_manage_view
from functions.group_reminder import add_group_event
from functions.leave_group import leave_group
from functions.members import get_group_members, kick, ban_confirmation, ban
from functions.notification import notification_time, change_notification, skip_notification_time, \
    disable_notification_time
from functions.plan import plan_event
from functions.command_view import command_view, event_command_view, command_back
from functions.private_join import private_join
from functions.reminder import add_event
from functions.rename_event import change_event_name, rename_event
from functions.rename_group import rename_group, change_group_name
from functions.start import start
from functions.time import timestamp, change_time
from inline_bot.i_start import inlinequery
# utils
from utils import CALENDAR, EVENT, NOTIFICATION, REMINDER, TIME, PUBLISH_TEXT, TEXT_CONFIRM, updater

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


def main() -> None:
    # initialize dispatcher
    dispatcher = updater.dispatcher
    # global fallback
    global_fallback = [MessageHandler(Filters.command, cancel), CallbackQueryHandler(cancel, pattern=r'\w{1,64}')]
    # handlers
    start_handler = CommandHandler('start', start)
    join_handler = CommandHandler('join', join_group, pass_args=True)
    member_handler = CommandHandler('members', get_group_members, pass_args=True)
    mygroups_handler = CommandHandler('mygroups', mygroups)
    command_handler = CommandHandler('commands', command_view)
    group_handler = CommandHandler('create', add_group, pass_args=True)
    group_manage_handler = CommandHandler('manage', manage_group, pass_args=True)
    publish_news_handler = ConversationHandler(
        entry_points=[CommandHandler('apublish', admin_publish)],
        states={
            PUBLISH_TEXT: [MessageHandler(Filters.text & ~Filters.command,
                                          publish_text)
                           ],
            TEXT_CONFIRM: [MessageHandler(Filters.text & ~Filters.command,
                                          send_publish_text)
                           ],
        },
        fallbacks=global_fallback
    )
    events_handler = ConversationHandler(
        entry_points=[
            CommandHandler('events', events),
            CallbackQueryHandler(events, pattern=r"Event::\w{3,8}")
        ],
        states={
            0: [
                CallbackQueryHandler(event_cal)
            ]
        },
        fallbacks=global_fallback
    )
    rename_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(change_group_name,
                                 pattern=r'Change name::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
        ],
        states={
            0: [
                MessageHandler(Filters.text & ~Filters.command, rename_group)
            ]
        },
        fallbacks=global_fallback
    )
    change_event_name_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(change_event_name, pattern=r'Change event name::\d{1,256}')],
        states={
            0: [MessageHandler(Filters.text & ~Filters.command,
                               rename_event)]
        },
        fallbacks=global_fallback)
    change_event_date_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(change_event_date, pattern=r'Change date::\d{1,256}')],
        states={
            0: [CallbackQueryHandler(redate_event)]
        },
        fallbacks=global_fallback)
    change_event_time_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(change_event_time, pattern=r'Change time::\d{1,256}')],
        states={
            0: [MessageHandler(Filters.text & ~Filters.command,
                               retime_event)]
        },
        fallbacks=global_fallback)
    change_event_notification_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(change_notification_event, pattern=r'Change notification::\d{1,256}')],
        states={
            0: [MessageHandler(Filters.text & ~Filters.command,
                               renotify),
                CommandHandler('disable', disable_change_notification_time)]
        },
        fallbacks=global_fallback)
    plan_handler = ConversationHandler(
        entry_points=[CommandHandler('plan', plan_event), CallbackQueryHandler(plan_event, pattern="Plan;;")],
        states={
            EVENT: [
                MessageHandler(Filters.text & ~Filters.command, event_init)
            ],
            CALENDAR: [
                CallbackQueryHandler(cal)
            ],
            TIME: [
                MessageHandler(Filters.text & ~Filters.command, timestamp)
            ],
            NOTIFICATION: [
                MessageHandler(Filters.text & ~Filters.command, notification_time),
                CommandHandler('skip', skip_notification_time),
                CommandHandler('disable', disable_notification_time)
            ],
            REMINDER: [
                CallbackQueryHandler(add_event),
                CommandHandler('name', change_event),
                CommandHandler('date', change_date),
                CommandHandler('time', change_time),
                CommandHandler('notification', change_notification)
            ]
        },
        fallbacks=global_fallback
    )
    group_plan_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(plan_group_event,
                                 pattern=r'Plan event::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b'),
            CallbackQueryHandler(privacy_change_confirmation,
                                 pattern=r'First event::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b::\w{1}')
        ],
        states={
            EVENT: [
                MessageHandler(Filters.text & ~Filters.command, event_init)
            ],
            CALENDAR: [
                CallbackQueryHandler(cal)
            ],
            TIME: [
                MessageHandler(Filters.text & ~Filters.command, timestamp)
            ],
            NOTIFICATION: [
                MessageHandler(Filters.text & ~Filters.command, notification_time),
                CommandHandler('skip', skip_notification_time),
                CommandHandler('disable', disable_notification_time)
            ],
            REMINDER: [
                CallbackQueryHandler(add_group_event),
                CommandHandler('name', change_event),
                CommandHandler('date', change_date),
                CommandHandler('time', change_time),
                CommandHandler('notification', change_notification)
            ]
        },
        fallbacks=global_fallback
    )

    # callbacks
    delete_handler = CallbackQueryHandler(delete_group,
                                          pattern=r'Delete::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
    ban_confirmation_handler = CallbackQueryHandler(ban_confirmation,
                                                    pattern=r'\d{9,12}::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b::ban ')
    ban_handler = CallbackQueryHandler(ban,
                                       pattern=r'\d{9,12}::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b::ban::\w{1}')
    kick_handler = CallbackQueryHandler(kick,
                                        pattern=r'\d{9,12}::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b::kick')
    member_callback_handler = CallbackQueryHandler(get_group_members,
                                                   pattern=r'Members::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
    group_list_view_handler = CallbackQueryHandler(group_list_view, pattern=r'Group list view::\d{1,7}')
    private_join_handler = CallbackQueryHandler(private_join,
                                                pattern=r'Join ::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b::\d{9,12}::\w{1}')
    change_privacy_handler = CallbackQueryHandler(change_privacy,
                                                  pattern=r'Privacy::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
    group_manage_view_handler = CallbackQueryHandler(group_manage_view,
                                                     pattern=r'Group manage view::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
    leave_group_handler = CallbackQueryHandler(leave_group,
                                               pattern=r'Leave::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
    get_group_id_handler = CallbackQueryHandler(get_group_id,
                                                pattern=r'Group id::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
    delete_event_handler = CallbackQueryHandler(delete_event, pattern=r'Delete event::\d{1,256}')
    show_all_group_events_handler = CallbackQueryHandler(show_events,
                                                         pattern=r'Show events::\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b')
    event_command_view_handler = CallbackQueryHandler(event_command_view, pattern="Events::select")
    command_back_handler = CallbackQueryHandler(command_back, pattern="Commands::back")
    group_list_callback_view_handler = CallbackQueryHandler(mygroups, pattern="Mygroups")

    # dispatchers
    dispatcher.add_handler(start_handler, 1)
    dispatcher.add_handler(plan_handler, 2)
    dispatcher.add_handler(publish_news_handler, 3)
    dispatcher.add_handler(events_handler, 4)
    dispatcher.add_handler(group_handler, 1)
    dispatcher.add_handler(group_list_callback_view_handler, 1)
    dispatcher.add_handler(join_handler, 1)
    dispatcher.add_handler(group_plan_handler)
    dispatcher.add_handler(member_handler, 1)
    dispatcher.add_handler(mygroups_handler, 1)
    dispatcher.add_handler(ban_confirmation_handler, 1)
    dispatcher.add_handler(command_back_handler, 1)
    dispatcher.add_handler(ban_handler, 1)
    dispatcher.add_handler(kick_handler, 1)
    dispatcher.add_handler(rename_handler, 9)
    dispatcher.add_handler(delete_handler, 1)
    dispatcher.add_handler(command_handler, 1)
    dispatcher.add_handler(change_privacy_handler, 1)
    dispatcher.add_handler(group_list_view_handler, 1)
    dispatcher.add_handler(private_join_handler, 1)
    dispatcher.add_handler(group_manage_view_handler, 1)
    dispatcher.add_handler(event_command_view_handler, 1)
    dispatcher.add_handler(member_callback_handler, 1)
    dispatcher.add_handler(leave_group_handler, 1)
    dispatcher.add_handler(group_manage_handler, 1)
    dispatcher.add_handler(get_group_id_handler, 1)
    dispatcher.add_handler(delete_event_handler, 1)
    dispatcher.add_handler(change_event_date_handler, 5)
    dispatcher.add_handler(change_event_name_handler, 6)
    dispatcher.add_handler(change_event_time_handler, 7)
    dispatcher.add_handler(change_event_notification_handler, 8)
    dispatcher.add_handler(show_all_group_events_handler, 1)
    dispatcher.add_handler(InlineQueryHandler(inlinequery))

    # hour checker
    schedule_timer.enter(3600, 1, check_hour)

    # starter
    updater.start_polling()
    #schedule_timer.run()
    updater.idle()


if __name__ == '__main__':
    main()

from datetime import date

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram_bot_calendar import LSTEP

from functions.custom_calendar import CustomCalendar
from utils import EVENT, CALENDAR, REMINDER, event_data
from functions.event_confirmation import event_confirmation

def change_event(update, context):
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id=chat_id, text="What's the event name?")
    context.user_data['prev_state'] = REMINDER
    return EVENT


def event_init(update, context):
    chat_id = update.effective_chat.id
    user_event_data = event_data[chat_id]
    user_event_data['event_name'] = update.message.text
    if context.user_data['prev_state'] == REMINDER:
        event_confirmation(update,context)

        return REMINDER
    else:
        context.bot.send_message(chat_id=chat_id,
                                 text=f"Event added {user_event_data['event_name']}")

        context.bot.send_message(chat_id, "When does the event happen?")
        calendar, step = CustomCalendar(min_date=date.today(),
                                        max_date=date.today().replace(year=date.today().year + 3)).build()
        context.bot.send_message(chat_id, f"Select {LSTEP[step]}", reply_markup=calendar)
        context.user_data['prev_state'] = EVENT
        return CALENDAR

from uuid import uuid4

import psycopg2.extras
from telegram.ext import ConversationHandler

from utils import connect_to_database, cursor


def add_group(update, context):
    try:
        chat_id = update.effective_chat.id
        cursor.execute(f"call insert_new_tracker({chat_id}, 'create')")
        connect_to_database.commit()
        
        if len(context.args) == 0:
            context.bot.send_message(chat_id=chat_id, text="Please enter group name after /create")
        else:
            psycopg2.extras.register_uuid()
            group_id = uuid4()
            group_name = ' '.join(context.args)
            cursor.execute("call insert_new_group(%s, %s, %s)",
                           (group_id, group_name, chat_id))

            connect_to_database.commit()

            context.bot.send_message(chat_id=chat_id,
                                     text=f"Group {group_name} created successfully. Give the following id to people you want to join this group")

            context.bot.send_message(chat_id=chat_id, text=f'{group_id}')
        return ConversationHandler.END

    except:
        context.bot.send_message(chat_id=chat_id,
                         text=f"You already created the group with name {group_name}")
        connect_to_database.rollback()
        return ConversationHandler.END

from copy import deepcopy

from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def group_list_view(update, context, groups=None, index=None):
    if update.callback_query == None or update.callback_query.data == "Mygroups":
        chat_id = update.effective_chat.id
        context.user_data['groups_list_view'] = groups
        page = index
        if len(context.user_data['groups_list_view']) > 1:
            context.user_data['groups_list_view'][page].append([])

            context.user_data['groups_list_view'][page][-1].append(
                InlineKeyboardButton(f"Page {page + 1}", callback_data="None"))

            context.user_data['groups_list_view'][page][-1].append(
                InlineKeyboardButton("⏩", callback_data=f"Group list view::{page + 1}"))
        reply_markup = InlineKeyboardMarkup(context.user_data['groups_list_view'][page])
        context.bot.send_message(chat_id=chat_id, text=f"Your groups", reply_markup=reply_markup)
    else:
        query = update.callback_query
        page = int(query.data.split('::')[1])
        group = deepcopy(context.user_data['groups_list_view'][page])
        if len(group) < 6:
            group.append([])

        if page != 0:
            group[-1].append(
                InlineKeyboardButton("⏪", callback_data=f"Group list view::{page - 1}"))

            group[-1].append(
                InlineKeyboardButton(f"Page {page + 1}", callback_data="None"))



        if page != len(context.user_data['groups_list_view']) - 1 and page != 0:
            group[-1].append(
                InlineKeyboardButton("⏩", callback_data=f"Group list view::{page + 1}"))

        reply_markup = InlineKeyboardMarkup(group)
        context.bot.edit_message_text(f"Your groups",
                                      query.message.chat.id,
                                      query.message.message_id,
                                      reply_markup=reply_markup)

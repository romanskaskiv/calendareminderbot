from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from utils import EVENT, event_data, cursor, connect_to_database


def plan_start_view(update, context, group_id):
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id=chat_id, text="Planning new group event")
    context.bot.send_message(chat_id=chat_id, text="What's the event name?")

    event_data[chat_id] = {"event_name": None,
                           "selected_date": None,
                           "selected_time": None,
                           "time_until_event": {"Days": 0, "Hours": 0, "Minutes": 0},
                           "index": 0,
                           "group": group_id}
    context.user_data['prev_state'] = -1



def plan_group_event(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    group_id = query.data.split('::')[1]

    cursor.execute(f"select select_privacy('{group_id}')")
    privacy = cursor.fetchone()[0]

    cursor.execute(f"select select_total_events('{group_id}')")
    total = cursor.fetchone()[0]

    if privacy == 'public' and total == 0:
        keyboard = [[
            InlineKeyboardButton("\u2714", callback_data=f'First event::{group_id}::y'),
            InlineKeyboardButton("\u2717", callback_data=f'First event::{group_id}::n'),
        ]]
        reply_markup = InlineKeyboardMarkup(keyboard)

        context.bot.send_message(chat_id=chat_id, text="Please notice that your group is public.\n"
                                                       "Do you want to switch to private?", reply_markup=reply_markup)
        context.user_data["group_view_message_id"] = query.message.message_id
    else:
        plan_start_view(update, context, group_id)
        return EVENT

def privacy_change_confirmation(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    group_id, confirmation = query.data.split('::')[1:]
    if confirmation == 'y':
        cursor.execute(f"select update_privacy('{group_id}')")
        connect_to_database.commit()
        privacy = cursor.fetchone()[0]

        cursor.execute(f"select select_group_name('{group_id}')")
        group_name = cursor.fetchone()[0]

        context.bot.edit_message_text(f"Your group {group_name} is now private",
                                      query.message.chat.id,
                                      query.message.message_id)

        keyboard = [[InlineKeyboardButton("Plan event", callback_data=f'Plan event::{group_id}'),
                     InlineKeyboardButton("Show events", callback_data=f'Show events::{group_id}')],
                    [InlineKeyboardButton("Change name", callback_data=f'Change name::{group_id}'),
                     InlineKeyboardButton("Delete", callback_data=f'Delete::{group_id}')],
                    [InlineKeyboardButton("Members", callback_data=f'Members::{group_id}'),
                     InlineKeyboardButton("Group Id", callback_data=f'Group id::{group_id}')],
                    [InlineKeyboardButton(f"Privacy: {privacy}", callback_data=f'Privacy::{group_id}')]]
        reply_markup = InlineKeyboardMarkup(keyboard)

        context.bot.edit_message_text(f"{group_name}",
                                      query.message.chat.id,
                                      context.user_data["group_view_message_id"],
                                      reply_markup=reply_markup)

        plan_start_view(update, context, group_id)
    else:
        context.bot.edit_message_text("Your group will remain public",
                                      query.message.chat.id,
                                      query.message.message_id)
        plan_start_view(update, context, group_id)
    return EVENT
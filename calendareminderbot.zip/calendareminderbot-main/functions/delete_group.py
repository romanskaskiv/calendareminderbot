from utils import cursor, connect_to_database

from functions.delete_event import delete_event

def delete_group(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    group_id = query.data.split('::')[1]

    cursor.execute(f"select select_group_name('{group_id}')")
    group_name = cursor.fetchone()[0]

    cursor.execute(f"select * from select_all_group_events('{group_id}')")
    events = cursor.fetchall()
    update.callback_query = None

    for event in events:
        context.user_data['event_id'] = event[2]
        delete_event(update, context)

    cursor.execute(f"call delete_group('{group_id}')")
    connect_to_database.commit()
    context.bot.edit_message_text(f"{group_name} deleted",
                                  query.message.chat.id,
                                  query.message.message_id)

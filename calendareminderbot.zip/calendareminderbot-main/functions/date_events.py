from datetime import date, datetime, timedelta

from telegram.ext import ConversationHandler
from telegram_bot_calendar import LSTEP

from functions.custom_calendar import CustomCalendar
from functions.event_manage_view import event_manage_view
from utils import cursor, connect_to_database


def send_date_events(update, context, selected_date, first_message=None):
    chat_id = update.effective_chat.id

    if first_message != None:
        context.bot.send_message(chat_id=chat_id, text=first_message)
    if selected_date != None:
        cursor.execute(
            "select * from select_all_user_events(%s, %s)",
            (chat_id, selected_date)
        )
    else:
        cursor.execute(
            f"select * from select_all_user_events({chat_id})",
        )
    date_events = cursor.fetchall()
    if len(date_events) == 0:
        context.bot.send_message(chat_id=chat_id, text="You have no events planned")
    for row in date_events:
        msg = f"Event: {row[0]}\n"
        if selected_date == None:
            msg += f"Date: {row[4]}\n"
        msg += f"Time: {row[1]}"
        if row[3] == chat_id:
            event_manage_view(update, context, row[2], msg, True)
        else:
            event_manage_view(update, context, row[2], msg, False)


def events(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    cursor.execute(f"call insert_new_tracker({chat_id}, 'events')")
    connect_to_database.commit()

    if query != None:
        sdate = query.data.split('::')[1]
    else:
        if len(context.args) == 0:
            sdate = 'specific'
        else:
            sdate = context.args[0]

    select_date(update, context, sdate)
    if sdate == 'specific':
        return 0
    else:
        return ConversationHandler.END


def event_cal(update, context):
    query = update.callback_query
    result, key, step = CustomCalendar(min_date=date.today()).process(query.data)
    if not result and key:
        context.bot.edit_message_text(f"Select {LSTEP[step]}",
                                      query.message.chat.id,
                                      query.message.message_id,
                                      reply_markup=key)
    elif result:
        context.bot.edit_message_text(f"On date {result}",
                                      query.message.chat.id,
                                      query.message.message_id)

        send_date_events(update, context, result)
        return ConversationHandler.END


def select_date(update, context, sdate):
    chat_id = update.effective_chat.id

    if sdate == 'specific':
        calendar, step = CustomCalendar(min_date=date.today(),
                                        max_date=date.today().replace(year=date.today().year + 3)).build()
        context.bot.send_message(chat_id, f"Select {LSTEP[step]}", reply_markup=calendar)
        return 0

    elif sdate == 'today':
        send_date_events(update, context, datetime.today().date(), "Events today")
        return ConversationHandler.END

    elif sdate == 'tomorrow':
        tomorrow = datetime.today().date() + timedelta(days=1)

        send_date_events(update, context, tomorrow, "Events tomorrow")
        return ConversationHandler.END

    elif sdate == 'all':
        send_date_events(update, context, None, "All events")
        return ConversationHandler.END

import datetime as dt

from telegram.ext import (ConversationHandler)

from functions.remove_jobs import requeue_jobs
from utils import cursor, connect_to_database


def change_event_name(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    event_id = query.data.split('::')[1]
    context.user_data['query'] = query
    context.bot.send_message(chat_id=chat_id, text=f"New event name: ")
    context.user_data['event_id'] = int(event_id)
    return 0


def rename_event(update, context):
    chat_id = update.effective_chat.id

    cursor.execute(f"select * from select_event_info({context.user_data['event_id']})")
    event_info = cursor.fetchone()

    old_msg = context.user_data['query'].message.text

    new_event_text = ''

    new_event_text += f"Event: {update.message.text}\n"

    if 'Date:' in old_msg.replace(event_info[0], '', 1):
        new_event_text += f"Date: {event_info[1]}\n"

    new_event_text += f"Time: {event_info[2]}"

    cursor.execute("call change_event_name(%s, %s)", (context.user_data['event_id'], update.message.text))
    connect_to_database.commit()
    context.bot.send_message(chat_id=chat_id,
                             text=f"Event name changed successfully")

    context.bot.edit_message_text(new_event_text, chat_id, context.user_data['query'].message.message_id,
                                  reply_markup=context.user_data['query'].message.reply_markup)

    sd = dt.datetime.combine(event_info[1], event_info[2])
    td = event_info[3]

    msg = f"Event \nName: {update.message.text}\n" \
          f"Date: {event_info[1]}\n" \
          f"Time: {event_info[2]}"

    requeue_jobs(update, context, sd, td, msg)

    return ConversationHandler.END

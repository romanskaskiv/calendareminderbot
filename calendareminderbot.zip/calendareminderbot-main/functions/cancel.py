from telegram.ext import ConversationHandler


def cancel(update, context):
    return ConversationHandler.END

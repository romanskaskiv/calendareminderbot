from utils import cursor, PUBLISH_TEXT, TEXT_CONFIRM
from telegram import ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ConversationHandler


def admin_publish(update, context):
  chat_id = update.effective_chat.id
  try:
      cursor.execute(f'select check_if_is_admin({chat_id})')
      admin = cursor.fetchone()[0]
      if admin:
        context.bot.send_message(chat_id=chat_id, text="Send me what I need to publish")
        return PUBLISH_TEXT
      else:
        raise Exception("You are not allowed to publish")
  except Exception as e:
      context.bot.send_message(chat_id=chat_id, text=f"{str(e)}")

def publish_text(update, context):
  context.user_data["publish_text"] = update.message.text
  chat_id = update.effective_chat.id
  reply_keyboard = [['Yes ☑️', 'No ❌']]

  update.message.reply_text(
        'Publish this text?',
        reply_markup=ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True, resize_keyboard=True),
    )

  return TEXT_CONFIRM

def send_publish_text(update, context):
  chat_id = update.effective_chat.id
  if update.message.text[:2] == 'No':
    update.message.reply_text('Send me what I need to publish', reply_markup=ReplyKeyboardRemove(),)
    return PUBLISH_TEXT
  
  cursor.execute('select * from get_all_conversation_id()')
  chat_ids = cursor.fetchall()

  update.message.reply_text('Ok', reply_markup=ReplyKeyboardRemove())
  for chat_id in chat_ids:
    try:
        context.bot.send_message(chat_id=chat_id[0], text=context.user_data["publish_text"])
    except Exception:
        pass

  return ConversationHandler.END
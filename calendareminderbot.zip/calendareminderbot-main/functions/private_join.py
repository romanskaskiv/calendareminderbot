from functions.insert_patricipant import insert_participant
from utils import cursor, Bot


def private_join(update, context):
    query = update.callback_query
    group_id, chat_id, confirmation = query.data.split('::')[1:]

    cursor.execute(f"select select_group_name('{group_id}')")
    group_name = cursor.fetchone()[0]

    participant_info = Bot.getChat(chat_id)

    if confirmation == 'y':

        context.bot.send_message(chat_id=chat_id, text=f"Your request to join '{group_name}' has been approved")

        insert_participant(update, context, group_id, chat_id)

        context.bot.edit_message_text(
            f"[{participant_info.first_name}](tg://user?id={participant_info.id}) joined '{group_name}'",
            query.message.chat.id,
            query.message.message_id,
            parse_mode='MarkdownV2')
    else:
        context.bot.send_message(chat_id=chat_id, text=f"Your request to join '{group_name}' has been denied")

        context.bot.edit_message_text(
            f"[{participant_info.first_name}](tg://user?id={participant_info.id})'s request to join '{group_name}' has been denied",
            query.message.chat.id,
            query.message.message_id,
            parse_mode='MarkdownV2')

import datetime as dt

from telegram.ext import ConversationHandler

from functions.changed_data_checker import changed_data_checker
from functions.remove_jobs import requeue_jobs
from utils import time_units, cursor, connect_to_database


def change_notification_event(update, context):
    query = update.callback_query
    context.user_data['event_id'] = int(query.data.split('::')[1])
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id=chat_id,
                             text="You can /disable this notification\n"
                                  "How long before the event starts do you want to be reminded of it?")

    context.bot.send_message(chat_id=chat_id, text=f"{time_units[0]}:")

    context.user_data['index'] = 0
    context.user_data['time_until_event'] = {'Days': 0, 'Hours': 0, 'Minutes': 0}
    return 0


def renotify(update, context):
    try:
        chat_id = update.effective_chat.id
        index = context.user_data['index']
        time_unit = update.message.text

        if not time_unit.strip('-').isnumeric():
            raise ValueError("Please use numbers only")

        time_unit = int(time_unit)

        if time_unit < 0:
            raise ValueError(f"{time_units[index]} can't be negative")

        context.user_data['time_until_event'][time_units[index]] = time_unit

        if context.user_data['time_until_event']['Hours'] > 23:
            raise ValueError('Hours must be in 0..23')

        if context.user_data['time_until_event']['Minutes'] > 59:
            raise ValueError('Minutes must be in 0..59')

        if index < 2:
            context.user_data['index'] += 1
            update.message.reply_text(f"{time_units[context.user_data['index']]}:")
        else:
            td = dt.timedelta(days=context.user_data['time_until_event']['Days'],
                              hours=context.user_data['time_until_event']['Hours'],
                              minutes=context.user_data['time_until_event']['Minutes'])

            cursor.execute(f"select * from select_event_info({context.user_data['event_id']})")
            event_info = cursor.fetchone()

            sd = dt.datetime.combine(event_info[1], event_info[2])

            if changed_data_checker(event_info[1], event_info[2], td):
                cursor.execute("call change_event_notification(%s, %s)", (context.user_data['event_id'], td))
                connect_to_database.commit()
                context.bot.send_message(chat_id=chat_id, text="Notification time changed")

                msg = f"Event \nName: {event_info[0]}\n" \
                      f"Date: {event_info[1]}\n" \
                      f"Time: {event_info[2]}"

                requeue_jobs(update, context, sd, td, msg)

            return ConversationHandler.END
    except ValueError as e:
        update.message.reply_text(f"{str(e)}")
        return ConversationHandler.END

def disable_change_notification_time(update, context):
    chat_id = update.effective_chat.id

    cursor.execute(f"select * from select_event_info({context.user_data['event_id']})")
    event_info = cursor.fetchone()

    sd = dt.datetime.combine(event_info[1], event_info[2])

    cursor.execute("call change_event_notification(%s, %s)", (context.user_data['event_id'], dt.timedelta()))
    connect_to_database.commit()

    msg = f"Event \nName: {event_info[0]}\n" \
          f"Date: {event_info[1]}\n" \
          f"Time: {event_info[2]}"

    requeue_jobs(update, context, sd, dt.timedelta(), msg)


    context.bot.send_message(chat_id=chat_id,
                             text="Disabled notification")
    return ConversationHandler.END
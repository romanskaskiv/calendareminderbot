from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from utils import Bot, cursor, connect_to_database


def member_menu(update, context, participant, group_id, edit_bool):
    query = update.callback_query
    chat_id = update.effective_chat.id
    cursor.execute(f"call insert_new_tracker({chat_id}, 'members')")
    connect_to_database.commit()

    keyboard = [[InlineKeyboardButton("Kick", callback_data=f'{participant}::{group_id}::kick'),
                 InlineKeyboardButton("Ban", callback_data=f'{participant}::{group_id}::ban ')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    participant_info = Bot.getChat(participant)

    if edit_bool:
        context.bot.edit_message_text(f"[{participant_info.first_name}](tg://user?id={participant_info.id})",
                                      query.message.chat.id,
                                      query.message.message_id,
                                      reply_markup=reply_markup,
                                      parse_mode='MarkdownV2')
    else:
        context.bot.send_message(chat_id=chat_id,
                                 text=f"[{participant_info.first_name}](tg://user?id={participant_info.id})",
                                 reply_markup=reply_markup,
                                 parse_mode='MarkdownV2')


def get_group_members(update, context):
    try:
        chat_id = update.effective_chat.id
        if update.callback_query != None:
            group_id = update.callback_query.data.split('::')[1]
        else:
            group_name = ' '.join(context.args)
            cursor.execute("select select_group_id(%s, %s)", (group_name, chat_id))
            group_id = cursor.fetchone()[0]
            if group_name == "":
                raise Exception('Please enter group name after /members')

        cursor.execute(f"SELECT get_group_members('{group_id}')")
        participants = cursor.fetchall()
        if len(participants) == 1:
            context.bot.send_message(chat_id=chat_id, text="There are no members in this group")

        else:
            cursor.execute(f"select select_total_users('{group_id}')")
            total_users = cursor.fetchone()[0]
            context.bot.send_message(chat_id=chat_id, text=f"{total_users} members")

        for participant in participants:
            if chat_id != participant[0]:
                member_menu(update, context, participant[0], group_id, False)
    except Exception as e:
        context.bot.send_message(chat_id=chat_id, text=f"{str(e)}")


def kick(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    participant, group_id, action = query.data.split('::')
    cursor.execute("call kick_member(%s, %s, %s)", (group_id, int(participant), False))
    connect_to_database.commit()
    context.bot.edit_message_text(f"User kicked", query.message.chat.id,
                                  query.message.message_id)


def ban_confirmation(update, context):
    query = update.callback_query
    participant, group_id, action = query.data.split('::')
    keyboard = [[InlineKeyboardButton("\u2714", callback_data=f'{participant}::{group_id}::ban::y'),
                 InlineKeyboardButton("\u2717", callback_data=f'{participant}::{group_id}::ban::n')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    context.bot.edit_message_text(f"Are you sure you want to ban this user?",
                                  query.message.chat.id,
                                  query.message.message_id,
                                  reply_markup=reply_markup)


def ban(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    participant, group_id, action, confirmation = query.data.split('::')

    if confirmation == 'y':
        cursor.execute("call kick_member(%s, %s, %s)", (group_id, int(participant), True))
        connect_to_database.commit()
        context.bot.edit_message_text(f"User banned",
                                      query.message.chat.id,
                                      query.message.message_id)
    else:
        member_menu(update, context, participant, group_id, True)

from utils import cursor, connect_to_database


def leave_group(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    group_id = query.data.split('::')[1]
    cursor.execute('call leave_group(%s, %s)', (group_id, chat_id))
    connect_to_database.commit()

    cursor.execute(f"select select_group_name('{group_id}')")
    group_name = cursor.fetchone()[0]
    context.bot.send_message(chat_id=chat_id, text=f"Left group {group_name}.\nEnter following command to rejoin:")
    context.bot.send_message(chat_id=chat_id, text=f"/join {group_id}")

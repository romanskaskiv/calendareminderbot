from datetime import time as tm
from datetime import timedelta

from telegram.ext import ConversationHandler

import functions.reminder
from functions.changed_data_checker import changed_data_checker
from functions.event_confirmation import event_confirmation
from utils import NOTIFICATION, TIME, REMINDER, event_data, time_units


def change_time(update, context):
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id=chat_id, text="When does the event start?")
    context.user_data['prev_state'] = REMINDER
    return TIME


def check_valid_time(message):
    signs = [' ', ',', ';', ':', '.']

    if len(list(filter(lambda x: x in signs, message))) > 1:
        raise Exception("Invalid input")

    if len(message) <= 2:
        if message.isnumeric():
            hour, minutes = message, 0
            return hour, minutes
        else:
            raise Exception("Wrong input")
    elif message[1] in signs:
        hour, minutes = message.split(message[1])
    elif message[2] in signs:
        hour, minutes = message.split(message[2])
    else:
        raise Exception("No delimiter found in expected position")

    if not hour.isnumeric() or not minutes.isnumeric():
        raise Exception("Values are not numeric")
    return hour, minutes


def timestamp(update, context):
    try:
        chat_id = update.effective_chat.id
        user_event_data = event_data[chat_id]
        if len(update.message.text) > 5:
            raise Exception("Incorrect length!")

        hour, minutes = check_valid_time(update.message.text)
        user_event_data['selected_time'] = tm(int(hour), int(minutes))
        update.message.reply_text(f"You entered: {user_event_data['selected_time'].strftime('%H:%M')}")

        functions.notification.index = 0

        if context.user_data['prev_state'] == REMINDER:
            event_confirmation(update, context)
            return REMINDER

        else:
            try:
                changed_data_checker(user_event_data['selected_date'], user_event_data['selected_time'], timedelta())
            except:
                context.bot.send_message(chat_id=chat_id, text="Can't go back in time")
                return ConversationHandler.END

            context.bot.send_message(chat_id=chat_id,
                                     text="You can /skip this part or /disable notification\n"
                                          "How long before the event starts do you want to be reminded of it?")

            context.bot.send_message(chat_id=chat_id, text=f"{time_units[0]}:")

            context.user_data['prev_state'] == TIME

            return NOTIFICATION
    except Exception as e:
        update.message.reply_text(f"{str(e)}. Try again")

from datetime import datetime

from functions.reminder import send_reminder
from utils import connect_to_database, cursor


def insert_participant(update, context, group_id, chat_id):
    cursor.execute("call insert_participant_id (%s, %s)",
                   (group_id, chat_id))
    connect_to_database.commit()

    cursor.execute(f"select * from select_all_group_events('{group_id}')")
    events = cursor.fetchall()

    for event in events:
        cursor.execute(f"select * from select_event_info('{event[2]}')")
        event_info = cursor.fetchone()
        selected_date = datetime.combine(event_info[1], event_info[2])
        if event_info[3].total_seconds() != 0 and (selected_date - event_info[3]) > datetime.now():
            msg = f"Event {event_info[0]} will occur on {event_info[1]} {event_info[2]}"

            context.job_queue.run_once(send_reminder,
                                       (selected_date - event_info[3] - datetime.now()).total_seconds(),
                                       context=[chat_id, msg], name=f"{str(event[2])}n")

        msg = f"Event {event_info[0]} occurs now"
        context.job_queue.run_once(send_reminder, (selected_date - datetime.now()).total_seconds(),
                                   context=[chat_id, msg], name=str(event[2]))

    cursor.execute(f"select select_group_name('{group_id}')")
    group_name = cursor.fetchone()[0]

    context.bot.send_message(chat_id=chat_id, text=f"You joined '{group_name}' group")

from functions.event_manage_view import event_manage_view
from utils import cursor


def show_events(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    group_id = query.data.split('::')[1]
    cursor.execute(f"select * from select_all_group_events('{group_id}')")
    events = cursor.fetchall()

    cursor.execute(f"select get_group_admin('{group_id}')")
    admin_id = cursor.fetchone()[0]

    if len(events) == 0:
        context.bot.send_message(chat_id=chat_id, text="No events planned")

    admin_bool = True

    if chat_id != admin_id:
        admin_bool = False

    for row in events:
        msg = f"Event: {row[0]}\nDate:{row[3]}\nTime:{row[1]}"

        event_manage_view(update, context, row[2], msg, admin_bool)

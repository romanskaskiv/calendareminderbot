from telegram.ext import ConversationHandler

from utils import cursor, connect_to_database


def change_group_name(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    group_id = query.data.split('::')[1]

    cursor.execute(f"select select_group_name('{group_id}')")
    group_name = cursor.fetchone()[0]
    context.user_data['message_id'] = query.message.message_id
    context.user_data['message_reply_markup'] = query.message.reply_markup
    context.bot.send_message(chat_id=chat_id, text=f"Change group's name from {group_name} to:")
    context.user_data['group_name'] = group_name
    return 0


def rename_group(update, context):
    chat_id = update.effective_chat.id
    cursor.execute("select select_group_id(%s, %s)", (context.user_data['group_name'], chat_id))
    group_id = cursor.fetchone()[0]
    cursor.execute("call change_name(%s, %s)", (group_id, update.message.text))
    connect_to_database.commit()
    context.bot.send_message(chat_id=chat_id,
                             text=f"Group's name changed from {context.user_data['group_name']} to "
                                  f"{update.message.text} successfully")
    context.bot.edit_message_text(f"{update.message.text}", chat_id, context.user_data['message_id'],
                                  reply_markup=context.user_data['message_reply_markup'])
    return ConversationHandler.END

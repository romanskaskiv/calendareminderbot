from datetime import datetime


def changed_data_checker(date, time, timedelta):
    if datetime.combine(date, time) < datetime.now():
        raise ValueError("can't go back in time")
    elif datetime.combine(date, time) - timedelta < datetime.now():
        raise ValueError("can't change with given notification input")
    else:
        return True

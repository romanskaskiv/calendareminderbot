import sched
import time
from datetime import datetime as dt
from utils import connect_to_database, cursor

schedule_timer = sched.scheduler(time.time, time.sleep)

def check_hour():
    if dt.now().hour == 0:
      cursor.execute('call delete_past_events()')
      connect_to_database.commit()

      schedule_timer.enter(3600*24, 1, check_hour)
    else:
      schedule_timer.enter(3600, 1, check_hour)

from functions.group_manage_view import group_manage_view
from utils import cursor, connect_to_database


def manage_group(update, context):
    try:
        chat_id = update.effective_chat.id
        cursor.execute(f"call insert_new_tracker({chat_id}, 'manage_group')")
        connect_to_database.commit()

        if len(context.args) == 0:
            context.bot.send_message(chat_id=chat_id, text="Please enter group name after /manage")
        else:
            group_name = ' '.join(context.args)
            cursor.execute("select select_group_id(%s, %s)", (group_name, chat_id))
            group_id = cursor.fetchone()[0]

            group_manage_view(update, context, group_name, group_id)
    except:
        context.bot.send_message(chat_id=chat_id,
                                 text=f"You haven't created a group called {group_name}")

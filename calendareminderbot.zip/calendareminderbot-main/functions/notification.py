from datetime import timedelta

from telegram.ext import ConversationHandler

from functions.changed_data_checker import changed_data_checker
from functions.event_confirmation import event_confirmation
from utils import REMINDER, NOTIFICATION, event_data, time_units


def change_notification(update, context):
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id=chat_id,
                             text="You can /skip this part or /disable notification\n"
                                  "How long before the event starts do you want to be reminded of it?")

    context.bot.send_message(chat_id=chat_id, text=f"{time_units[0]}:")

    user_event_data = event_data[chat_id]
    user_event_data['index'] = 0

    return NOTIFICATION


def notification_time(update, context):
    try:
        chat_id = update.effective_chat.id
        user_event_data = event_data[chat_id]
        index = user_event_data['index']
        time_unit = update.message.text

        if not time_unit.strip('-').isnumeric():
            raise ValueError("Please use numbers only")

        time_unit = int(time_unit)

        if time_unit < 0:
            raise ValueError(f"{time_units[index]} can't be negative")

        user_event_data['time_until_event'][time_units[index]] = time_unit

        if user_event_data['time_until_event']['Hours'] > 23:
            raise ValueError('Hours must be in 0..23')

        if user_event_data['time_until_event']['Minutes'] > 59:
            raise ValueError('Minutes must be in 0..59')

        if index < 2:
            user_event_data['index'] += 1
            update.message.reply_text(f"{time_units[user_event_data['index']]}:")
        else:
            interval = timedelta(days=user_event_data['time_until_event']['Days'],
                                 hours=user_event_data['time_until_event']['Hours'],
                                 minutes=user_event_data['time_until_event']['Minutes'])
            try:
                changed_data_checker(user_event_data['selected_date'], user_event_data['selected_time'], interval)
            except:
                context.bot.send_message(chat_id=chat_id, text="Can't go back in time")
                return ConversationHandler.END

            days = user_event_data['time_until_event']['Days']
            hours = user_event_data['time_until_event']['Hours']
            minutes = user_event_data['time_until_event']['Minutes']

            msg = ''

            if days != 0:
                msg += f'{days} days '

            if hours != 0:
                msg += f'{hours} hours '

            if minutes != 0:
                msg += f'{minutes} minutes '

            if msg == '':
                msg = 'You will not be reminded'

            else:
                msg = 'You will be reminded ' + msg + 'before the event starts'

            update.message.reply_text(msg)

            event_confirmation(update, context)

            return REMINDER
    except ValueError as e:
        update.message.reply_text(f"{str(e)}")


def skip_notification_time(update, context):
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id=chat_id,
                             text="Skipped notification reminding")
    event_confirmation(update, context)
    return REMINDER


def disable_notification_time(update, context):
    chat_id = update.effective_chat.id
    user_event_data = event_data[chat_id]

    user_event_data['time_until_event']['Days'] = 0
    user_event_data['time_until_event']['Hours'] = 0
    user_event_data['time_until_event']['Minutes'] = 0

    context.bot.send_message(chat_id=chat_id,
                             text="Disabled notification")
    event_confirmation(update, context)
    return REMINDER

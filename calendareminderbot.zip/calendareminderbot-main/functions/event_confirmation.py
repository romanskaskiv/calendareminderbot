from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def event_confirmation(update, context):
    chat_id = update.effective_chat.id
    keyboard = [
        [
            InlineKeyboardButton("\u2714", callback_data='1'),
            InlineKeyboardButton("\u2717", callback_data='2'),
        ]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)

    context.bot.send_message(chat_id=chat_id,
                             text='Do you want to add this event?\nuse /name, /date, /time, /notification\n'
                                  'to change name, date, time, notification respectively',
                             reply_markup=reply_markup)

from datetime import date

from telegram_bot_calendar import LSTEP

from functions.custom_calendar import CustomCalendar
from functions.event_confirmation import event_confirmation
from utils import TIME, REMINDER, CALENDAR, event_data


def change_date(update, context):
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id, "When does the event happen?")
    calendar, step = CustomCalendar(min_date=date.today(),
                                    max_date=date.today().replace(year=date.today().year + 3)).build()
    context.bot.send_message(chat_id, f"Select {LSTEP[step]}", reply_markup=calendar)
    context.user_data['prev_state'] = REMINDER
    return CALENDAR


def cal(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    user_event_data = event_data[chat_id]
    result, key, step = CustomCalendar(min_date=date.today()).process(query.data)
    if not result and key:
        context.bot.edit_message_text(f"Select {LSTEP[step]}",
                                      query.message.chat.id,
                                      query.message.message_id,
                                      reply_markup=key)
    elif result:
        user_event_data['selected_date'] = result
        context.bot.edit_message_text(f"You selected {result}",
                                      query.message.chat.id,
                                      query.message.message_id)
        if context.user_data['prev_state'] == REMINDER:
            event_confirmation(update, context)

            return REMINDER
        else:
            context.bot.send_message(chat_id=chat_id, text="When does the event start?")
            context.user_data['prev_state'] == CALENDAR
            return TIME

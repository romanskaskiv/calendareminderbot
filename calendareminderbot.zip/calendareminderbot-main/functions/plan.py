from utils import EVENT, event_data, connect_to_database, cursor


def plan_event(update, context):
    chat_id = update.effective_chat.id
    cursor.execute(f"call insert_new_tracker({chat_id}, 'plan')")
    connect_to_database.commit()
    
    context.bot.send_message(chat_id=chat_id, text="Planning new event")
    context.bot.send_message(chat_id=chat_id, text="What's the event name?")
    event_data[chat_id] = {'event_name': None,
                           'selected_date': None,
                           'selected_time': None,
                           'time_until_event': {'Days': 0, 'Hours': 0, 'Minutes': 0},
                           'index': 0}
    undefined_step = -1
    context.user_data['prev_state'] = undefined_step
    return EVENT

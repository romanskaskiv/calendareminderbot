from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def command_view(update, context):
    chat_id = update.effective_chat.id
    keyboard = [
        [InlineKeyboardButton("Plan", callback_data="Plan;;"),
         InlineKeyboardButton("Events", callback_data="Events::select")],
        [InlineKeyboardButton("My groups", callback_data="Mygroups")]]
    keyboard_markup = InlineKeyboardMarkup(keyboard)
    context.bot.send_message(chat_id=chat_id, text="Available commands", reply_markup=keyboard_markup)


def event_command_view(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    keyboard = [
        [InlineKeyboardButton("All", callback_data="Event::all")],
        [InlineKeyboardButton("Specific date", callback_data="Event::specific")],
        [InlineKeyboardButton("Today", callback_data="Event::today")],
        [InlineKeyboardButton("Tomorrow", callback_data="Event::tomorrow")],
        [InlineKeyboardButton("⏪ Back", callback_data="Commands::back")]]
    keyboard_markup = InlineKeyboardMarkup(keyboard)
    context.bot.edit_message_text(f"Select date",
                                  chat_id,
                                  query.message.message_id,
                                  reply_markup=keyboard_markup)


def command_back(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    keyboard = [
        [InlineKeyboardButton("Plan", callback_data="Plan"),
         InlineKeyboardButton("Events", callback_data="Events::select")],
        [InlineKeyboardButton("My groups", callback_data="Mygroups")]]
    keyboard_markup = InlineKeyboardMarkup(keyboard)
    context.bot.edit_message_text(f"Available commands",
                                  chat_id,
                                  query.message.message_id,
                                  reply_markup=keyboard_markup)

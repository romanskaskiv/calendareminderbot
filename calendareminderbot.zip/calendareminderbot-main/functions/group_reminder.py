import datetime as dt

from telegram.ext import ConversationHandler

from functions.message_parser import message_parser
from functions.reminder import send_reminder
from utils import connect_to_database, cursor, event_data


def add_group_event(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    user_event_data = event_data[chat_id]
    if query.data == '1':
        try:
            e_name = user_event_data['event_name']
            e_date = user_event_data['selected_date']
            e_time = user_event_data['selected_time']
            e_group = user_event_data['group']

            sd = e_date
            st = e_time
            sd = dt.datetime.combine(sd, st)
            td = dt.timedelta(days=user_event_data['time_until_event']['Days'],
                              hours=user_event_data['time_until_event']['Hours'],
                              minutes=user_event_data['time_until_event']['Minutes'])
            notification_time = sd - td

            if notification_time < dt.datetime.now() or sd < dt.datetime.now():
                raise ValueError("I can't go back in time")

            cursor.execute('select select_insert_group_notification(%s, %s, %s, %s, %s, %s)',
                           (chat_id, e_name, e_date, e_time, e_group, td))
            event_id = cursor.fetchone()[0]
            connect_to_database.commit()

            cursor.execute(f"select select_all_participant_chat_id('{e_group}')")
            participants = cursor.fetchall()

            cursor.execute(f"select select_group_name('{e_group}')")
            group_name = cursor.fetchone()[0]

            parsed_group = message_parser(group_name)
            parsed_date = message_parser(str(e_date))
            parsed_name = message_parser(e_name)

            msg_create = f"🟠 Notification for group *{parsed_group}*\n\n" \
                         f"🟢 Event \nName: {parsed_name}" \
                         f"\nDate: {parsed_date}" \
                         f"\nTime: {e_time}"

            msg_notification = f"🟠 Notification for group *{parsed_group}*\n\n" \
                               f"Event *{parsed_name}* will occur on {parsed_date} {e_time}"

            msg_reminder = f"🚨 Notification for group *{parsed_group}*\n\n" \
                           f"Event *{parsed_name}* occurs now"

            for participant in participants:
                if participant[0] == chat_id:
                    context.bot.edit_message_text(msg_create,
                                                  query.message.chat.id,
                                                  query.message.message_id,
                                                  parse_mode='MarkdownV2')
                else:
                    context.bot.send_message(chat_id=participant[0], text=msg_create, parse_mode='MarkdownV2')

                if notification_time != sd:
                    context.job_queue.run_once(send_reminder, (notification_time - dt.datetime.now()).total_seconds(),
                                               context=[participant[0], msg_notification], name=f"{str(event_id)}n")

                context.job_queue.run_once(send_reminder, (sd - dt.datetime.now()).total_seconds(),
                                           context=[participant[0], msg_reminder], name=str(event_id))

            return ConversationHandler.END

        except ValueError as e:
            context.bot.send_message(chat_id=chat_id, text=f"{str(e)}")
            return ConversationHandler.END

    else:
        context.bot.edit_message_text("Ok then",
                                      query.message.chat.id,
                                      query.message.message_id)
        return ConversationHandler.END

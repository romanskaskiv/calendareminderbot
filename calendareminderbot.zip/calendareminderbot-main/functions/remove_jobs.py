import datetime as dt

from functions.reminder import send_reminder

from utils import cursor

def requeue_jobs(update, context, sd, td, msg):
    jobs_for_removal = context.job_queue.get_jobs_by_name(str(context.user_data['event_id']))
    notification_jobs_for_removal = context.job_queue.get_jobs_by_name(
        f"{str(context.user_data['event_id'])}n")

    if len(notification_jobs_for_removal) == 0:
        if td.total_seconds() != 0:
            cursor.execute(f"select select_group_id_by_event({context.user_data['event_id']})")
            group_id = cursor.fetchone()[0]
            if group_id != None:
                cursor.execute(f"select select_all_participant_chat_id('{group_id}')")
                participants = cursor.fetchall()
                for participant in participants:
                    context.job_queue.run_once(send_reminder, (sd - td - dt.datetime.now()).total_seconds(),
                                               context=[participant[0], msg],
                                               name=f"{str(context.user_data['event_id'])}n")
            else:
                context.job_queue.run_once(send_reminder, (sd - td - dt.datetime.now()).total_seconds(),
                                           context=[update.effective_chat.id, msg],
                                           name=f"{str(context.user_data['event_id'])}n")

    for job in jobs_for_removal:
        chat = job.context[0]
        job.schedule_removal()
        context.job_queue.run_once(send_reminder, (sd - dt.datetime.now()).total_seconds(),
                                   context=[chat, msg],
                                   name=str(context.user_data['event_id']))

        for job in notification_jobs_for_removal:
            chat = job.context[0]
            job.schedule_removal()
            if td.total_seconds() != 0:
                context.job_queue.run_once(send_reminder, (sd - td - dt.datetime.now()).total_seconds(),
                                           context=[chat, msg],
                                           name=f"{str(context.user_data['event_id'])}n")

from datetime import date, datetime

from telegram.ext import ConversationHandler
from telegram_bot_calendar import LSTEP

from functions.changed_data_checker import changed_data_checker
from functions.custom_calendar import CustomCalendar
from functions.remove_jobs import requeue_jobs
from utils import cursor, connect_to_database


def change_event_date(update, context):
    query = update.callback_query
    context.user_data['event_id'] = int(query.data.split('::')[1])
    context.user_data['query'] = query
    chat_id = update.effective_chat.id
    calendar, step = CustomCalendar(min_date=date.today(),
                                    max_date=date.today().replace(year=date.today().year + 3)).build()
    context.bot.send_message(chat_id, f"Select {LSTEP[step]}", reply_markup=calendar)
    context.user_data['next_state'] = ConversationHandler.END
    return 0


def redate_event(update, context):
    query = update.callback_query
    result, key, step = CustomCalendar(min_date=date.today()).process(query.data)
    chat_id = update.effective_chat.id
    if not result and key:
        context.bot.edit_message_text(f"Select {LSTEP[step]}",
                                      query.message.chat.id,
                                      query.message.message_id,
                                      reply_markup=key)
    elif result:
        context.bot.edit_message_text(f"You selected {result}",
                                      query.message.chat.id,
                                      query.message.message_id)

        cursor.execute(f"select * from select_event_info({context.user_data['event_id']})")
        event_info = cursor.fetchone()

        new_event_text = ''

        new_event_text += f"Event: {event_info[0]}\n"

        new_event_text += f"Date: {result}\n"

        new_event_text += f"Time: {event_info[2]}"

        if changed_data_checker(result, event_info[2], event_info[3]):
            cursor.execute(
                "call change_event_date(%s, %s)",
                (context.user_data['event_id'], result)
            )
            connect_to_database.commit()

            context.bot.edit_message_text(f"Event date changed to {result}",
                                          query.message.chat.id,
                                          query.message.message_id)

            context.bot.edit_message_text(new_event_text, chat_id, context.user_data['query'].message.message_id,
                                          reply_markup=context.user_data['query'].message.reply_markup)

            msg = f"Event \nName: {event_info[0]}\n" \
                  f"Date: {result}\n" \
                  f"Time: {event_info[2]}"

            sd = datetime.combine(result, event_info[2])
            td = event_info[3]

            requeue_jobs(update, context, sd, td, msg)

        return ConversationHandler.END

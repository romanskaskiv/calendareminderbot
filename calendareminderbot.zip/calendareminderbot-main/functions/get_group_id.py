def get_group_id(update, context):
    chat_id = update.effective_chat.id
    query = update.callback_query
    group_id = query.data.split('::')[1]
    context.bot.send_message(chat_id=chat_id, text=group_id)

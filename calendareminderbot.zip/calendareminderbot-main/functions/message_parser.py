import re

def message_parser(msg):
    special_characters = '\\_*[]()~`>#+-=|{}.!'
    for character in special_characters:
        msg = msg.replace(f"{character}", f"\{character}")
    return msg


import datetime as dt

from telegram.ext import ConversationHandler

from functions.message_parser import message_parser
from utils import connect_to_database, cursor, event_data


def send_reminder(context):
    context.bot.send_message(chat_id=context.job.context[0], text=context.job.context[1], parse_mode='MarkdownV2')


def add_event(update, context):
    query = update.callback_query
    chat_id = update.effective_chat.id
    user_event_data = event_data[chat_id]
    if query.data == '1':
        try:
            e_name = user_event_data['event_name']
            e_date = user_event_data['selected_date']
            e_time = user_event_data['selected_time']

            selected_date = dt.datetime.combine(e_date, e_time)
            remaining_date = dt.timedelta(days=user_event_data['time_until_event']['Days'],
                                          hours=user_event_data['time_until_event']['Hours'],
                                          minutes=user_event_data['time_until_event']['Minutes'])
            notification_time = selected_date - remaining_date

            if notification_time < dt.datetime.now() or selected_date < dt.datetime.now():
                raise ValueError("I can't go back in time")

            msg_t = "🔴 Notification\n\n"
            parsed_name = message_parser(e_name)
            msg = f"🟢 Event \nName: {e_name}"

            parsed_date = message_parser(str(e_date))
            msg += f"\nDate: {e_date}"
            msg += f"\nTime: {e_time}"
            context.bot.edit_message_text(f"{msg}",
                                          query.message.chat.id,
                                          query.message.message_id)

            cursor.execute("select select_insert_event_notification(%s, %s, %s, %s, %s)",
                           (chat_id, e_name, e_date, e_time, remaining_date))
            connect_to_database.commit()
            event_id = cursor.fetchone()[0]

            if notification_time != selected_date:
                msg = f"Your event *{parsed_name}* will occur on {parsed_date} {e_time}"
                msg_t += msg
                context.job_queue.run_once(send_reminder, (notification_time - dt.datetime.now()).total_seconds(),
                                           context=[chat_id, msg_t], name=f"{str(event_id)}n")
                msg_t = "🚨 Notification\n\n"

            msg = f"Your event *{parsed_name}* occurs now"
            msg_t += msg
            context.job_queue.run_once(send_reminder, (selected_date - dt.datetime.now()).total_seconds(),
                                       context=[chat_id, msg_t], name=str(event_id))

            return ConversationHandler.END

        except ValueError as e:
            context.bot.send_message(chat_id=chat_id, text=f"{str(e)}")
            return ConversationHandler.END

    else:
        context.bot.edit_message_text("Ok then",
                                      query.message.chat.id,
                                      query.message.message_id)
        return ConversationHandler.END

from telegram import InlineKeyboardButton

from functions.group_list_view import group_list_view
from utils import cursor, connect_to_database


def mygroups(update, context):
    chat_id = update.effective_chat.id
    cursor.execute(f"call insert_new_tracker({chat_id}, 'mygroups')")
    connect_to_database.commit()

    cursor.execute(f"SELECT * from get_groups({chat_id})")
    groups = cursor.fetchall()
    if len(groups) == 0:
        context.bot.send_message(chat_id=chat_id, text="You don't belong to any group")

    fullpages = len(groups) // 5
    page = 0

    pages = []
    while page < fullpages:
        groups_page = groups[5 * page: 5*(page + 1)]
        user_page = []
        for group in groups_page:
            cursor.execute(f"Select select_group_id(%s, %s)", (group[0], group[1]))
            group_id = cursor.fetchone()[0]

            cursor.execute(f"Select get_group_admin('{group_id}')")
            admin_id = cursor.fetchone()[0]

            if admin_id == chat_id:
                user_page.append([
                    InlineKeyboardButton(f"{group[0]} admin", callback_data=f"Group manage view::{group_id}")])
            else:
                user_page.append([
                    InlineKeyboardButton(f"{group[0]}", callback_data=f"Group manage view::{group_id}")])

        pages.append(user_page)
        page += 1

    if len(groups) % 5:
        groups_page = groups[5 * page:]
        user_page = []

        for group in groups_page:
            cursor.execute(f"Select select_group_id(%s, %s)", (group[0], group[1]))
            group_id = cursor.fetchone()[0]

            cursor.execute(f"Select get_group_admin('{group_id}')")
            admin_id = cursor.fetchone()[0]

            if admin_id == chat_id:
                user_page.append([
                    InlineKeyboardButton(f"{group[0]} admin", callback_data=f"Group manage view::{group_id}")])
            else:
                user_page.append([
                    InlineKeyboardButton(f"{group[0]}", callback_data=f"Group manage view::{group_id}")])
        pages.append(user_page)

    group_list_view(update, context, pages, 0)

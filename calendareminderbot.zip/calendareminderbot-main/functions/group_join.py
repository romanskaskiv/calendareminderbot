from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from functions.insert_patricipant import insert_participant
from utils import cursor, connect_to_database


def join_group(update, context):
    chat_id = update.effective_chat.id
    cursor.execute(f"call insert_new_tracker({chat_id}, 'group_join')")
    connect_to_database.commit()

    if len(context.args) == 0:
        context.bot.send_message(chat_id=chat_id, text="Please enter group id after /join")
    else:
        cursor.execute("select check_ban(%s, %s)", (context.args[0], chat_id))
        ban = cursor.fetchone()[0]

        if ban:
            context.bot.send_message(chat_id=chat_id, text="You have been banned from this group")
        else:
            cursor.execute(f"select select_privacy('{context.args[0]}')")
            privacy = cursor.fetchone()[0]

            if privacy == 'public':
                insert_participant(update, context, context.args[0], chat_id)
            else:
                user_info = update.message.chat

                cursor.execute(f"select select_group_name('{context.args[0]}')")
                group_name = cursor.fetchone()[0]

                cursor.execute(f"select get_group_admin('{context.args[0]}')")
                admin = cursor.fetchone()[0]

                keyboard = [[
                    InlineKeyboardButton("\u2714", callback_data=f'Join ::{context.args[0]}::{chat_id}::y'),
                    InlineKeyboardButton("\u2717", callback_data=f'Join ::{context.args[0]}::{chat_id}::n'),
                ]]

                reply_markup = InlineKeyboardMarkup(keyboard)

                context.bot.send_message(chat_id=admin,
                                         text=f"[{user_info.first_name}](tg://user?id={user_info.id}) wants to join your '{group_name}' group\nAccept?",
                                         reply_markup=reply_markup,
                                         parse_mode='MarkdownV2')

                context.bot.send_message(chat_id=chat_id, text="Your request has been sent to the group admin")

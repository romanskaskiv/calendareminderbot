from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from utils import cursor


def group_manage_view(update, context, group_name=None, group_id=None):
    chat_id = update.effective_chat.id
    if update.callback_query == None:
        group_name = group_name
        group_id = group_id
    else:
        query = update.callback_query
        group_id = query.data.split('::')[1]
        cursor.execute(f"select select_group_name('{group_id}')")
        group_name = cursor.fetchone()[0]

    cursor.execute(f"select check_group_id('{group_id}')")
    exists = cursor.fetchone()[0]

    if exists:
        cursor.execute(f"select get_group_admin('{group_id}')")
        group_admin = cursor.fetchone()[0]

        if chat_id == group_admin:
            cursor.execute(f"select select_privacy('{group_id}')")
            privacy = cursor.fetchone()[0]
            keyboard = [[InlineKeyboardButton("Plan event", callback_data=f'Plan event::{group_id}'),
                         InlineKeyboardButton("Show events", callback_data=f'Show events::{group_id}')],
                        [InlineKeyboardButton("Change name", callback_data=f'Change name::{group_id}'),
                         InlineKeyboardButton("Delete", callback_data=f'Delete::{group_id}')],
                        [InlineKeyboardButton("Members", callback_data=f'Members::{group_id}'),
                         InlineKeyboardButton("Group Id", callback_data=f'Group id::{group_id}')],
                        [InlineKeyboardButton(f"Privacy: {privacy}", callback_data=f'Privacy::{group_id}')]]
            reply_markup = InlineKeyboardMarkup(keyboard)

        else:
            keyboard = [[InlineKeyboardButton("Show events", callback_data=f'Show events::{group_id}')],
                        [InlineKeyboardButton("Leave", callback_data=f'Leave::{group_id}')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
        context.bot.send_message(chat_id=chat_id, text=f'{group_name}', reply_markup=reply_markup)
    else:
        context.bot.send_message(chat_id=chat_id, text=f"This group doesn't exist")

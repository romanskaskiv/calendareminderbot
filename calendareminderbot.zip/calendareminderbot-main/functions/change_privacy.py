from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from utils import cursor, connect_to_database


def change_privacy(update, context):
    query = update.callback_query
    group_id = query.data.split('::')[1]

    cursor.execute(f"select update_privacy('{group_id}')")
    connect_to_database.commit()
    privacy = cursor.fetchone()[0]

    cursor.execute(f"select select_group_name('{group_id}')")
    group_name = cursor.fetchone()[0]

    keyboard = [[InlineKeyboardButton("Plan event", callback_data=f'Plan event::{group_id}'),
                 InlineKeyboardButton("Show events", callback_data=f'Show events::{group_id}')],
                [InlineKeyboardButton("Change name", callback_data=f'Change name::{group_id}'),
                 InlineKeyboardButton("Delete", callback_data=f'Delete::{group_id}')],
                [InlineKeyboardButton("Members", callback_data=f'Members::{group_id}'),
                 InlineKeyboardButton("Group Id", callback_data=f'Group id::{group_id}')],
                [InlineKeyboardButton(f"Privacy: {privacy}", callback_data=f'Privacy::{group_id}')]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    context.bot.edit_message_text(f'{group_name}',
                                  query.message.chat.id,
                                  query.message.message_id,
                                  reply_markup=reply_markup
                                  )

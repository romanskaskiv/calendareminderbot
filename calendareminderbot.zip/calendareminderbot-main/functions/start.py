from utils import connect_to_database, cursor

def start(update, context):
    un = update.message.chat.first_name
    chat_id = update.effective_chat.id

    try:
        cursor.execute(f'call insert_new_user({chat_id})')
        connect_to_database.commit()

        context.bot.send_message(chat_id=chat_id, text=f"Sign up successful, welcome {un}.")
    except:
        context.bot.send_message(chat_id=chat_id, text="You are already signed in")

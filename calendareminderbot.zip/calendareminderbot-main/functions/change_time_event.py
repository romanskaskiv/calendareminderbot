from datetime import time, datetime

from telegram.ext import ConversationHandler

from functions.changed_data_checker import changed_data_checker
from functions.remove_jobs import requeue_jobs
from functions.time import check_valid_time
from utils import cursor, connect_to_database


def change_event_time(update, context):
    query = update.callback_query
    context.user_data['event_id'] = int(query.data.split('::')[1])
    context.user_data['query'] = query
    chat_id = update.effective_chat.id
    context.bot.send_message(chat_id=chat_id, text="New event start time:")
    return 0


def retime_event(update, context):
    try:
        chat_id = update.effective_chat.id

        if len(update.message.text) > 5:
            raise Exception("Incorrect length!")

        hour, minutes = check_valid_time(update.message.text)
        selected_time = time(int(hour), int(minutes))

        cursor.execute(f"select * from select_event_info({context.user_data['event_id']})")
        event_info = cursor.fetchone()

        old_msg = context.user_data['query'].message.text

        new_event_text = ''

        new_event_text += f"Event: {event_info[0]}\n"

        if 'Date:' in old_msg.replace(event_info[0], '', 1):
            new_event_text += f"Date: {event_info[1]}\n"

        new_event_text += f"Time: {selected_time}"

        if changed_data_checker(event_info[1], selected_time, event_info[3]):
            cursor.execute("call change_event_time(%s, %s)", (context.user_data['event_id'], selected_time))
            connect_to_database.commit()
            context.bot.send_message(chat_id=chat_id,
                                     text=f"Event start time changed to {selected_time.strftime('%H:%M')}")

            context.bot.edit_message_text(new_event_text, chat_id, context.user_data['query'].message.message_id,
                                          reply_markup=context.user_data['query'].message.reply_markup)

            msg = f"Event \nName: {event_info[0]}\n" \
                  f"Date: {event_info[1]}\n" \
                  f"Time: {selected_time}"

            sd = datetime.combine(event_info[1], selected_time)
            td = event_info[3]

            requeue_jobs(update, context, sd, td, msg)

        return ConversationHandler.END
    except Exception as e:
        context.bot.send_message(chat_id=chat_id, text=f"{str(e)}")
        return ConversationHandler.END

from telegram.ext import ConversationHandler

from utils import cursor, connect_to_database


def delete_event(update, context):
    single_event_delete = False
    admin_chat_id = update.effective_chat.id
    if update.callback_query != None:
        query = update.callback_query
        single_event_delete = True
        context.user_data['event_id'] = int(query.data.split('::')[1])
        context.bot.edit_message_text("Event deleted",
                                      query.message.chat.id,
                                      query.message.message_id)

    cursor.execute(f"select * from select_event_info({context.user_data['event_id']})")
    event_name = cursor.fetchone()[0]

    cursor.execute(f"call delete_event({context.user_data['event_id']})")
    connect_to_database.commit()

    jobs_for_removal = context.job_queue.get_jobs_by_name(str(context.user_data['event_id']))
    notification_jobs_for_removal = context.job_queue.get_jobs_by_name(
        f"{str(context.user_data['event_id'])}n")


    for job in jobs_for_removal:
        user_chat_id = job.context[0]
        job.schedule_removal()
        if single_event_delete and user_chat_id != admin_chat_id:
            context.bot.send_message(chat_id=user_chat_id, text=f"*{event_name}* has been canceled",
                                     parse_mode="MarkdownV2")

    for job in notification_jobs_for_removal:
        job.schedule_removal()
    return ConversationHandler.END

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from utils import cursor
from datetime import datetime
def event_manage_view(update, context, event_id, msg, admin_bool):
    chat_id = update.effective_chat.id
    cursor.execute(f"select * from select_event_info({event_id})")
    event_info = cursor.fetchone()
    if admin_bool and datetime.combine(event_info[1], event_info[2]) > datetime.now():
        keyboard = [[InlineKeyboardButton("Change name", callback_data=f'Change event name::{event_id}')],
                    [InlineKeyboardButton("Change date", callback_data=f'Change date::{event_id}'),
                     InlineKeyboardButton("Change time", callback_data=f'Change time::{event_id}')],
                    [InlineKeyboardButton("Change notification",
                                          callback_data=f'Change notification::{event_id}')],
                    [InlineKeyboardButton("Delete", callback_data=f'Delete event::{event_id}')]]

        reply_markup = InlineKeyboardMarkup(keyboard)
        context.bot.send_message(chat_id=chat_id, text=msg,
                                 reply_markup=reply_markup)
    else:
        context.bot.send_message(chat_id=chat_id, text=msg)

from uuid import uuid4

from telegram import InlineQueryResultArticle, InputTextMessageContent, Update
from telegram.ext import CallbackContext
from utils import inline_result, inline_title


def get_formatted_message(query):
    result = 'Event:\n'

    for count, key in enumerate(inline_result):
        if len(query) > count:
            inline_result[key] = query[count]

    for i in inline_result:
        if inline_result[i]:
            result += f'{i.split("_")[1].capitalize()}: {inline_result[i]}\n'

    return result


def inlinequery(update: Update, cc: CallbackContext) -> None:
    query = update.inline_query.query.split('||')
    if query == ['']:
        return

    results = [
        InlineQueryResultArticle(
            id=str(uuid4()),
            title=inline_title,
            input_message_content=InputTextMessageContent(get_formatted_message(query)),
        ),
    ]

    update.inline_query.answer(results)

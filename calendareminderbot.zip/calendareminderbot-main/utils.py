# python-postgres
import os

import psycopg2
import telegram
# env variables
from dotenv import load_dotenv
from telegram.ext import Updater


load_dotenv()

connect_to_database = psycopg2.connect(database=os.getenv('DB_DATABASE'), user=os.getenv('DB_USER'),
                                       password=os.getenv('DB_PASSWORD'), host=os.getenv('DB_HOST'))

cursor = connect_to_database.cursor()

updater = Updater(token=os.getenv('TOKEN'))

Bot = telegram.Bot(token=os.getenv('TOKEN'))

job_queue = updater.job_queue

time_units = ['Days', 'Hours', 'Minutes']

event_data = {}

# states
EVENT = 0
CALENDAR = 1
TIME = 2
NOTIFICATION = 3
REMINDER = 4

# publish
PUBLISH_TEXT = 0
TEXT_CONFIRM = 1

inline_result = {
    'event_name': '',
    'event_date': '',
    'event_time': '',
    'event_notification_1': '',
    'event_notification_2': '',
}

inline_title = 'Name || Date (d.m.y) || Time (h:m) || Notification 1 || Notification 2'
